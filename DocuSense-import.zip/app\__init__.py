"""Multimodal document intelligence application."""
